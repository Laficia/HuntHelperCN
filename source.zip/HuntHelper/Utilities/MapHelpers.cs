using Dalamud.Game;
using Dalamud.Plugin.Services;
using HuntHelper.Managers.Hunts.Models;
using Lumina.Data;
using Lumina.Excel.Sheets;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;
using FFXIVClientStructs.FFXIV.Client.Game.UI;

namespace HuntHelper.Utilities;
/// <summary>
/// Rename this class... DataManagerUtil? ExcelUtil? idk
/// </summary>
public class MapHelpers
{
    private static Dictionary<string, string> ChineseToEnglish = new Dictionary<string, string>()
    {
        {"中拉诺西亚","Middle La Noscea"},{"拉诺西亚低地","Lower La Noscea"},{"东拉诺西亚","Eastern La Noscea"},{"西拉诺西亚","Western La Noscea"},{"拉诺西亚高地","Upper La Noscea"},{"拉诺西亚外地","Outer La Noscea"},//La Noscea
        {"黑衣森林中央林区","Central Shroud"},{"黑衣森林东部林区","East Shroud"},{"黑衣森林南部林区","South Shroud"},{"黑衣森林北部林区","North Shroud"},//Shroud
        {"西萨纳兰","Western Thanalan"},{"中萨纳兰","Central Thanalan"},{"东萨纳兰","Eastern Thanalan"},{"南萨纳兰","Southern Thanalan"},{"北萨纳兰","Northern Thanalan"},//Thanalan
        {"库尔札斯中央高地","Coerthas Central Highlands"},{"摩杜纳","Mor Dhona"},//2.0
        {"阿巴拉提亚云海","The Sea of Clouds"},{"魔大陆阿济兹拉","Azys Lla"},{"龙堡参天高地","The Dravanian Forelands"},{"翻云雾海","The Churning Mists"},{"龙堡内陆低地","The Dravanian Hinterlands"},{"库尔札斯西部高地","Coerthas Western Highlands"},//3.0
        {"基拉巴尼亚边区","The Fringes"},{"红玉海","The Ruby Sea"},{"基拉巴尼亚山区","The Peaks"},{"延夏","Yanxia"},{"基拉巴尼亚湖区","The Lochs"},{"太阳神草原","The Azim Steppe"},//4.0
        {"雷克兰德","Lakeland"},{"珂露西亚岛","Kholusia"},{"安穆·艾兰","Amh Araeng"},{"伊尔美格","Il Mheg"},{"拉凯提卡大森林","The Rak'tika Greatwood"},{"黑风海","The Tempest"},//5.0
        {"迷津","Labyrinthos"},{"萨维奈岛","Thavnair"},{"加雷马","Garlemald"},{"叹息海","Mare Lamentorum"},{"厄尔庇斯","Elpis"},{"天外天垓","Ultima Thule"},//6.0
        {"奥阔帕恰山", "Urqopacha"}, {"克扎玛乌卡湿地", "Kozama'uka"}, {"亚克特尔树海", "Yak T'el"}, {"夏劳尼荒野", "Shaaloani"}, {"遗产之地", "Heritage Found"}, {"活着的记忆", "Living Memory"}//7.0
    };

    public static IDataManager DataManager;
    private static IClientState _clientState;

    public static void SetUp(IDataManager dataManager, IClientState clientState)
    {
        DataManager = dataManager;
        _clientState = clientState;
    }

    public static string GetMapName(uint territoryID)
    //map id... territory id... confusing ...
    // KirisameVanilla: Map refers to the texture of a map. Territory refers to the zone of a map, like Lakeland.
    // KirisameVanilla: So in order to avoid confusing i suggest using 'Zone' instead of the word 'Map' in HuntHelper to distinguish texture map and zone map(territory)
    {
        return DataManager.Excel.GetSheet<TerritoryType>()?.GetRowOrDefault(territoryID)?.PlaceName.ValueNullable?.Name.ToString() ?? "未知地区";
    }
    public static string GetMapNameInEnglish(uint territoryID)
    {
        // The CN client need not contain English sheets. Branch before requesting one.
        if (_clientState.ClientLanguage == (ClientLanguage)4)
        {
            var mapName = GetMapName(territoryID);
            return ChineseToEnglish.TryGetValue(mapName, out var value) ? value : "location not found";
        }

        var row = DataManager.Excel.GetSheet<TerritoryType>(Language.English).GetRowOrDefault(territoryID)?.PlaceName.RowId ?? 0;
        return DataManager.Excel.GetSheet<PlaceName>(Language.English).GetRowOrDefault(row)?.Name.ToString() ?? "location not found";
    }

    public static uint GetMapID(uint territoryID) //createmaplink doesn't work with "Mor Dhona" :(
    {
        return DataManager.GetExcelSheet<TerritoryType>().GetRowOrDefault(territoryID)?.Map.RowId ?? 0;
    }

    public static string WorldCatalogError { get; private set; } = string.Empty;
    public static IReadOnlyList<HuntTrainWorld> GetImportableWorlds(uint currentWorldId)
    {
        WorldCatalogError = string.Empty;
        if (DataManager == null) { WorldCatalogError = "游戏服务器数据尚未就绪，请稍后刷新"; return Array.Empty<HuntTrainWorld>(); }
        try
        {
            var rows = new List<HuntWorldCatalogEntry>();
            foreach (var world in DataManager.GetExcelSheet<World>())
            {
                var dc = world.DataCenter.ValueNullable;
                rows.Add(new(world.RowId, world.Name.ToString(), world.DataCenter.RowId,
                    dc?.Name.ToString() ?? string.Empty, dc?.Region.RowId ?? 0, world.IsPublic));
            }
            var worlds = HuntWorldCatalog.Select(rows, currentWorldId, _clientState?.ClientLanguage == (ClientLanguage)4);
            if (worlds.Count == 0) WorldCatalogError = "暂未读取到可选服务器，请等待角色加载完成后刷新";
            return worlds;
        }
        catch (Exception ex)
        {
            WorldCatalogError = "读取服务器名单失败，请点击刷新重试";
            PluginLog.Warning(ex, "Unable to load the hunt world catalog");
            return Array.Empty<HuntTrainWorld>();
        }
    }

    //convert map scale (100/95) to map size (41/43.1)
    public static float MapScaleToMaxCoord(float mapScale) => (-0.42f) * mapScale + 83f;

    public static float ConvertToMapCoordinate(float pos, float mapScale)
    {
        return 2048f / mapScale + pos / 50f + 1f;
    }

    public static Vector2 ConvertToMapCoordinate(Vector3 pos, float mapScale)
    {
        return new Vector2(
            ConvertToMapCoordinate(pos.X, mapScale),
            ConvertToMapCoordinate(pos.Z, mapScale)
        );
    }

    public static void LocaliseMobNames(List<HuntTrainMob> trainList)
    {
        trainList.ForEach(m => m.Name = DataManager.Excel.GetSheet<BNpcName>()?.GetRowOrDefault(m.MobID)?.Singular.ToString() ?? m.Name);
    }

    public static string GetMobName(uint nameId, string fallback)
    {
        var name = DataManager.GetExcelSheet<BNpcName>().GetRowOrDefault(nameId)?.Singular.ToString();
        return string.IsNullOrWhiteSpace(name) ? fallback : name;
    }

    public static IReadOnlyDictionary<uint, uint> GetHuntTerritories(IEnumerable<uint> territories)
    {
        var result = new Dictionary<uint, uint>();
        foreach (var territory in territories)
        {
            var zone = DataManager.GetExcelSheet<TerritoryType>().GetRowOrDefault(territory);
            var notorious = zone?.NotoriousMonsterTerritory.ValueNullable;
            if (notorious == null) continue;
            foreach (var monster in notorious.Value.NotoriousMonsters)
            {
                var nameId = monster.ValueNullable?.BNpcName.RowId ?? 0;
                if (nameId != 0) result.TryAdd(nameId, territory);
            }
        }
        return result;
    }

    public static async Task<bool> MapImageVerUpToDate(string currentVersion)
    {
        var version = await GetMapImageVer().ConfigureAwait(false);
        return version.Length == 0 || currentVersion == version;
    }

    public static async Task<string> GetMapImageVer(CancellationToken cancellationToken = default)
    {
        try
        {
            using var client = new HttpClient { Timeout = TimeSpan.FromSeconds(15) };
            client.DefaultRequestHeaders.Add("Cache-Control", "no-cache");
            return (await client.GetStringAsync(ImageVerUrl, cancellationToken).ConfigureAwait(false)).Trim();
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
        catch (Exception error) when (error is HttpRequestException or OperationCanceledException)
        {
            // Optional metadata failure does not invalidate successfully cached images.
            return string.Empty;
        }
    }
    
    public static unsafe uint CurrentInstance => UIState.Instance()->PublicInstance.InstanceId;

    private static readonly string ImageVerUrl = @"https://raw.githubusercontent.com/img02/HuntHelper-Resources/main/version";
}
