// Based on NiGuangOwO/LuckyStar; modified 2026-11-13. AGPL-3.0-or-later.
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Plugin.Services;
using ECommons.DalamudServices;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.Game.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;

namespace LuckyStar;

public sealed unsafe class FarmController : IDisposable
{
    private readonly GameFarmHost host = new();
    public FarmSession Session { get; }
    public RubyPatrol Ruby { get; }
    private bool rubyMode;
    public bool IsRunning => Session.Running || Ruby.Running;
    public string State => rubyMode ? Ruby.State : Session.State;
    public bool ShowingRuby => rubyMode;
    public IReadOnlyDictionary<uint,int> Deaths => rubyMode ? Ruby.Deaths : Session.Deaths;
    private long nextUpdate;
    public FarmController() { Session = new(host); Ruby = new(host); Svc.Framework.Update += Update; }
    public void Dispose() { Svc.Framework.Update -= Update; Stop("插件已卸载"); }
    public void Stop(string reason = "已停止")
    {
        try { try { Session.Stop(reason); } finally { Ruby.Stop(reason); } }
        catch (Exception ex) { Svc.Log.Error(ex, "LuckyStarMOGAI stop failed"); }
    }
    public bool Start(FarmProfile profile, IEnumerable<Vector3> points)
    {
        if(IsRunning) return false;
        rubyMode=profile.Ground;
        if (!host.CombatAvailable) { Svc.Chat.PrintError("LuckyStarMOGAI：请先启用支持 /aeTargetSelector 与 /aepull 的 AE 自动战斗插件。"); return false; }
        Session.DelaySeconds = Plugin.Configuration.DelayEnable ? Plugin.Configuration.DelayTime : 0;
        Ruby.DelaySeconds = Session.DelaySeconds;
        try { return rubyMode ? Ruby.Start(profile,Plugin.Configuration.RubyCaves,Environment.TickCount64) : Session.Start(profile, points, Environment.TickCount64); }
        catch (Exception ex) { Stop("启动失败：请检查导航和 AE"); Svc.Log.Error(ex, "LuckyStarMOGAI start failed"); return false; }
    }
    public List<Vector3> RubyPoints(uint[] names)
    {
        var c = host.Context;
        return host.Mobs.Where(m => names.Contains(m.NameId) && m.Hp > 0 && FarmSession.Finite(m.Position) &&
            Vector3.Distance(m.Position, c.Position) <= 120 && Math.Abs(m.Position.Y - c.Position.Y) <= 18)
            .Select(m => m.Position).Distinct().Take(80).ToList();
    }
    private void Update(IFramework framework)
    {
        if (!IsRunning || Environment.TickCount64 < nextUpdate) return;
        nextUpdate = Environment.TickCount64 + 200;
        try { if(Ruby.Running) Ruby.Tick(Environment.TickCount64); else Session.Tick(Environment.TickCount64); }
        catch (Exception ex) { Stop("运行中断：请检查 vnavmesh 和 AE，详情见日志"); Svc.Log.Error(ex, "LuckyStarMOGAI farm tick failed"); }
    }
}

internal sealed unsafe class GameFarmHost : IFarmHost
{
    public FarmContext Context
    {
        get
        {
            var p = Svc.Objects.LocalPlayer;
            var loading = Svc.Condition[ConditionFlag.BetweenAreas] || Svc.Condition[ConditionFlag.BetweenAreas51] ||
                Svc.GameGui.GetAddonByName("NowLoading",1).IsVisible || Svc.GameGui.GetAddonByName("FadeMiddle",1).IsVisible || Svc.GameGui.GetAddonByName("FadeBack",1).IsVisible;
            var ready = Svc.ClientState.IsLoggedIn && p != null && !loading;
            return new(ready, new(p?.CurrentWorld.RowId ?? 0, Svc.ClientState.TerritoryType, UIState.Instance()->PublicInstance.InstanceId),
                p?.Position ?? Vector3.Zero, p?.CurrentHp == 0,
                Svc.Condition[ConditionFlag.OccupiedInCutSceneEvent] || Svc.Condition[ConditionFlag.WatchingCutscene78],
                Svc.Condition[ConditionFlag.InCombat], Svc.Condition[ConditionFlag.Mounted], Svc.Condition[ConditionFlag.InFlight],
                Svc.Condition[ConditionFlag.Diving], loading, Svc.ClientState.IsLoggedIn);
        }
    }
    public IReadOnlyList<FarmMob> Mobs => Svc.Objects.OfType<IBattleChara>()
        .Where(b => b.NameId is > 0 && b.EntityId != 0xE0000000)
        .Select(b => new FarmMob(b.GameObjectId, b.NameId, b.Position, b.CurrentHp, b.MaxHp)).ToList();
    public bool CombatAvailable => Svc.Commands.Commands.ContainsKey("/aeTargetSelector") && Svc.Commands.Commands.ContainsKey("/aepull");
    public bool NavigationReady => Svc.PluginInterface.GetIpcSubscriber<bool>("vnavmesh.Nav.IsReady") is { HasFunction: true } gate && gate.InvokeFunc();
    public bool NavigationBusy => Svc.PluginInterface.GetIpcSubscriber<bool>("vnavmesh.SimpleMove.PathfindInProgress").InvokeFunc() ||
        Svc.PluginInterface.GetIpcSubscriber<bool>("vnavmesh.Path.IsRunning").InvokeFunc();
    public bool MovementAllowed => Svc.PluginInterface.GetIpcSubscriber<bool>("vnavmesh.Path.GetMovementAllowed") is { HasFunction: true } gate && gate.InvokeFunc();
    public bool Move(Vector3 p, bool fly) => Svc.PluginInterface.GetIpcSubscriber<Vector3, bool, bool>("vnavmesh.SimpleMove.PathfindAndMoveTo").InvokeFunc(p, fly);
    public bool MoveDirect(Vector3 p,bool fly)
    {
        // Short preset portal corridor only. Native vnavmesh executor/settings, no coordinate writes.
        var gate=Svc.PluginInterface.GetIpcSubscriber<List<Vector3>,bool,object>("vnavmesh.Path.MoveTo");
        if(!gate.HasAction) return false;
        gate.InvokeAction([p],fly);return true;
    }
    public void StopMovement()
    {
        // Dispatch to the loaded CN plugin's own command handler; cancels pending calculation too.
        if (!Svc.Commands.ProcessCommand("/vnav stop"))
            Svc.PluginInterface.GetIpcSubscriber<object>("vnavmesh.Path.Stop").InvokeAction();
    }
    public void SetCombat(bool on)
    {
        if (!on)
        {
            try { Svc.Commands.ProcessCommand("/aeTargetSelector off"); }
            finally { Svc.Commands.ProcessCommand("/aepull off"); }
            return;
        }
        if (!CombatAvailable) throw new InvalidOperationException("AE commands unavailable");
        try
        {
            if (!Svc.Commands.ProcessCommand("/aeTargetSelector mode7") ||
                !Svc.Commands.ProcessCommand("/aeTargetSelector on") || !Svc.Commands.ProcessCommand("/aepull on"))
                throw new InvalidOperationException("AE command failed");
        }
        catch { SetCombat(false); throw; }
    }
    public void Focus(ulong id)
    {
        var b = Svc.Objects.FirstOrDefault(b => b.GameObjectId == id);
        if (b != null && Svc.Targets.Target?.GameObjectId != id) Svc.Targets.Target = b;
    }
    public void Mount() => ActionManager.Instance()->UseAction(ActionType.GeneralAction, 9);
    public void TakeOff() => ActionManager.Instance()->UseAction(ActionType.GeneralAction, 2);
    public void Dismount() => ActionManager.Instance()->UseAction(ActionType.GeneralAction, 23);
}



