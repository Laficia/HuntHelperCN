using Dalamud.Game.Command;
using Dalamud.Interface.Windowing;
using Dalamud.Plugin;
using ECommons;
using ECommons.DalamudServices;

namespace LuckyStar;

public sealed class Plugin : IDalamudPlugin
{
    private const string CommandName = "/luckystarmogai";
    public static Configuration Configuration = null!;
    public readonly WindowSystem WindowSystem = new("LuckyStarMOGAI");
    private MainWindow MainWindow { get; init; }

    public Plugin(IDalamudPluginInterface pluginInterface)
    {
        ECommonsMain.Init(pluginInterface, this);

        Configuration = Svc.PluginInterface.GetPluginConfig() as Configuration ?? new Configuration();
        Configuration.Initialize(Svc.PluginInterface);

        MainWindow = new MainWindow();
        WindowSystem.AddWindow(MainWindow);

        Svc.Commands.AddHandler(CommandName, new CommandInfo(OnCommand)
        {
            HelpMessage = "打开设置"
        });

        Svc.PluginInterface.UiBuilder.Draw += DrawUI;
        Svc.PluginInterface.UiBuilder.OpenConfigUi += ToggleMainUI;
        Svc.PluginInterface.UiBuilder.OpenMainUi += ToggleMainUI;
    }

    public void Dispose()
    {
        Svc.PluginInterface.UiBuilder.Draw -= DrawUI;
        Svc.PluginInterface.UiBuilder.OpenConfigUi -= ToggleMainUI;
        Svc.PluginInterface.UiBuilder.OpenMainUi -= ToggleMainUI;
        WindowSystem.RemoveAllWindows();
        MainWindow.Dispose();
        Svc.Commands.RemoveHandler(CommandName);
        ECommonsMain.Dispose();
    }

    private void OnCommand(string command, string args)
    {
        if (args.Trim().Equals("stop", System.StringComparison.OrdinalIgnoreCase)) MainWindow.Stop();
        else ToggleMainUI();
    }

    private void DrawUI() => WindowSystem.Draw();

    public void ToggleMainUI() => MainWindow.Toggle();
}



