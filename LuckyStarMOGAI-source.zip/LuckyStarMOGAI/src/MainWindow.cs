// Modified from NiGuangOwO/LuckyStar MainWindow, 2026-11-13. AGPL-3.0-or-later.
using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Colors;
using Dalamud.Interface.Windowing;
using ECommons.DalamudServices;
using System;
using System.Collections.Generic;
using System.Numerics;
namespace LuckyStar;
public sealed class MainWindow : Window, IDisposable
{
    private readonly FarmController controller = new();
    public MainWindow() : base("LuckyStarMOGAI 0.0.0.2###LuckyStarMOGAI")
    {
        Size = new Vector2(560,420); SizeCondition=ImGuiCond.FirstUseEver;
        SizeConstraints = new WindowSizeConstraints { MinimumSize=new(320,260), MaximumSize=new(float.MaxValue,float.MaxValue) };
    }
    public void Dispose()=>controller.Dispose();
    public void Stop()=>controller.Stop();
    public override void Draw()
    {
        var config=Plugin.Configuration;
        ImGui.PushStyleColor(ImGuiCol.Text,controller.IsRunning ? ImGuiColors.HealerGreen : ImGuiColors.DalamudWhite);
        ImGui.TextWrapped($"状态：{controller.State}");ImGui.PopStyleColor();
        if((controller.IsRunning || controller.CleanupFailed) && ImGui.Button("停止农怪")) controller.Stop();
        ImGui.Separator();
        ImGui.BeginDisabled(controller.IsRunning);
        var rotation=(int)config.Rotation;
        ImGui.SetNextItemWidth(Math.Max(150,ImGui.GetContentRegionAvail().X-90));
        if(ImGui.Combo("自动循环",ref rotation,CombatRotationSession.Names,CombatRotationSession.Names.Length))
        { config.Rotation=(RotationProvider)rotation;config.Save(); }
        if(config.Rotation is RotationProvider.RotationSolverReborn or RotationProvider.Prome)
        {
            if(ImGui.Checkbox("允许临时开启循环（停止农怪时关闭）",ref config.AllowRotationStart))config.Save();
            ImGui.TextWrapped(config.AllowRotationStart ? "已开启的循环保持原设置；由本插件启动的循环在离开点位／停止时关闭。RSR/Prome 无完整状态租约，请勿在托管中切换其模式。" : "请先在所选插件中开启循环；本插件只选怪与靠近，保持你的循环开关。");
        }
        if(controller.CombatAvailability is { Length:>0 } unavailable)
        {ImGui.PushStyleColor(ImGuiCol.Text,ImGuiColors.DalamudYellow);ImGui.TextWrapped(unavailable);ImGui.PopStyleColor();}
        var selected=config.SelectedFarm;
        ImGui.SetNextItemWidth(-1);
        if(ImGui.Combo("##农怪项目",ref selected,FarmProfiles.Titles,FarmProfiles.Titles.Length)) {config.SelectedFarm=selected;config.Save();}
        var choices=config.Selections[selected];
        for(var i=0;i<choices.Length;i++)
        {
            if(i>0 && ImGui.GetContentRegionAvail().X>180) ImGui.SameLine();
            if(ImGui.Checkbox(FarmProfiles.Labels[selected][i],ref choices[i])) config.Save();
        }
        if(selected==0)
        {
            ImGui.Spacing();
            for(var i=0;i<3;i++) if(ImGui.Checkbox($"{RubyCaves.All[i].Name} ({RubyCaves.All[i].Map.X:0.#}, {RubyCaves.All[i].Map.Y:0.#})",ref config.RubyCaves[i])) config.Save();
            ImGui.TextWrapped("先进入任一洞穴或在附近海底下潜，开始后三洞循环。洞内使用真实小怪位置步行巡怪；洞间潜水寻路，进出洞穴的加载动画自动等待。");
            ImGui.TextColored(ImGuiColors.DalamudYellow,FarmProfiles.EorzeaDate(DateTimeOffset.UtcNow.ToUnixTimeSeconds()));
            ImGui.TextWrapped("触发参考：两类各 100 只；满月 ET 第 16 日 12:00 起。还受 S 怪重生冷却影响，不保证触发。");
        }
        else ImGui.TextWrapped("使用原插件预设点位，上坐骑、起飞、巡点；请先到对应地图并开启飞行。");
        if(Svc.ClientState.TerritoryType!=FarmProfiles.Territories[selected])
            ImGui.TextColored(ImGuiColors.DalamudYellow,"请先前往该项目对应地图。");
        if(ImGui.Button("开始农怪",new Vector2(-1,0)))
        {
            var profile=FarmProfiles.Profile(selected,choices);
            var points=selected==0 ? controller.RubyPoints(profile.Names) : FarmProfiles.Preset(selected,choices);
            controller.Start(profile,points);
        }
        ImGui.EndDisabled();
        if(controller.ShowingRuby)
        {
            ImGui.Separator();
            ImGui.TextWrapped($"本次观测死亡：观梦螺 {controller.Deaths.GetValueOrDefault(5750u)}  /  无壳观梦螺 {controller.Deaths.GetValueOrDefault(5751u)}");
            ImGui.TextWrapped("只统计本机看见的存活 → 死亡；不代表个人击杀或全服进度。");
        }
        ImGui.Spacing();
        if(ImGui.CollapsingHeader("选项与依赖"))
        {
            ImGui.BeginDisabled(controller.IsRunning);
            if(ImGui.Checkbox("每轮首只小怪延迟",ref config.DelayEnable)) config.Save();
            if(config.DelayEnable && ImGui.SliderInt("秒",ref config.DelayTime,0,120)) config.Save();
            ImGui.EndDisabled();
            ImGui.TextWrapped("需要国服 vnavmesh（API 15），自动循环可选 AE、RSR、Wrath 或 Prome。请在所选插件中先配置当前职业。Wrath 使用临时租约，停止时释放；严格限定目标时请在 Wrath 关闭 AoEIgnoreManual（群体忽略手动目标）。");
            ImGui.TextWrapped("RSR 需要 AutorotationActive / ChangeOperatingMode 接口，部分旧版不提供。Prome 保留自身验证与 ACR 要求，不改 AutoPull 设置。缺少接口或拒绝启动时会明确停止。");
            if(controller.IsRunning)ImGui.TextWrapped(controller.CombatStatus);
            ImGui.TextWrapped("切服、切图、切分线、死亡、导航中断和卡住会停止。也可使用 /luckystarmogai stop；不会修改 vnavmesh 的手动操控、镜头或容差设置。请勿同时运行原 LuckyStar 或 HHT 找怪。");
        }
        if(ImGui.CollapsingHeader("关于与许可证"))
        {
            ImGui.TextWrapped("原作 NiGuangOwO/LuckyStar，定制修改 Laficia（2026-11-13）。AGPL-3.0-or-later；无担保，可按该许可证再分发与修改。完整许可随包附带 LICENSE.md，对应源码见仓库 LuckyStarMOGAI-source.zip。");
            ImGui.TextWrapped("https://github.com/Laficia/HuntHelperCN");
        }
    }
}


