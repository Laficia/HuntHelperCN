// LuckyStarCN changes, 2026-11-13. AGPL-3.0-or-later.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;

namespace LuckyStar;

public readonly record struct FarmScope(uint World, uint Territory, uint Instance);
public readonly record struct FarmMob(ulong Id, uint NameId, Vector3 Position, uint Hp, uint MaxHp);
public sealed record FarmProfile(string Name, uint Territory, uint[] Names, bool Ground, uint StopOnName = 0, bool RequireAllTargets = true);
public readonly record struct FarmContext(bool Ready, FarmScope Scope, Vector3 Position,
    bool Dead, bool Busy, bool Combat, bool Mounted, bool Flying, bool Diving,
    bool Loading = false, bool LoggedIn = true);

public interface IFarmHost
{
    FarmContext Context { get; }
    IReadOnlyList<FarmMob> Mobs { get; }
    bool NavigationReady { get; }
    bool NavigationBusy { get; }
    bool MovementAllowed { get; }
    float EngageDistance => 25;
    bool Move(Vector3 position, bool fly);
    bool MoveDirect(Vector3 position, bool fly);
    void StopMovement();
    void SetCombat(bool enabled);
    void Focus(ulong id);
    void Mount();
    void TakeOff();
    void Dismount();
}

/// <summary>One session belongs to one world, territory and instance. No server progress is inferred.</summary>
public sealed class FarmSession(IFarmHost host)
{
    public bool Running { get; private set; }
    public string State { get; private set; } = "未运行";
    public FarmProfile? Profile { get; private set; }
    public IReadOnlyList<Vector3> Points => _points;
    public int Index { get; private set; }
    public int RoundsCompleted { get; private set; }
    public Dictionary<uint, int> Deaths { get; } = [];
    public int DelaySeconds { get; set; }
    private List<Vector3> _points = [];
    private FarmScope _scope;
    private bool _moving, _combatOn, _chasing, _approachingTarget;
    private long _moveAt, _progressAt, _actionAt, _waitUntil, _targetSince;
    private Vector3 _lastProgress, _moveGoal;
    private ulong _target;
    private readonly Dictionary<ulong, FarmMob> _observed = [];

    public bool Start(FarmProfile profile, IEnumerable<Vector3> points, long now)
    {
        if (Running) return Reject("请先停止当前农怪");
        var c = host.Context;
        if (!c.Ready || c.Dead || c.Busy || c.Combat || c.Scope.World == 0) return Reject("请先登录、脱战并等待地图加载完成");
        if (c.Scope.Territory != profile.Territory) return Reject("请先前往对应地图：" + profile.Name);
        if (profile.Names.Length == 0) return Reject("请至少选择一种小怪");
        if (profile.Ground && (c.Mounted || c.Flying || c.Diving)) return Reject("请先进入海底洞穴的陆地并下坐骑，再开始巨大鳐农怪");
        if (!host.NavigationReady || !host.MovementAllowed) return Reject("请安装并启用 vnavmesh，等待网格就绪并允许移动");
        if (host.NavigationBusy) return Reject("vnavmesh 正在移动，请先停止其他路线");
        var valid = points.Where(Finite).Distinct().ToList();
        if (valid.Count == 0) return Reject("没有可用点位；红玉海请站在有两类观梦螺的洞穴陆地上");
        if (profile.Ground && profile.RequireAllTargets && profile.Names.Any(n => !host.Mobs.Any(m => m.NameId == n && m.Hp > 0 &&
            Vector3.Distance(m.Position, c.Position) <= 120 && Math.Abs(m.Position.Y - c.Position.Y) <= 18)))
            return Reject("附近未找到每种已勾选的小怪；请靠近两类观梦螺，或调整勾选后重试");
        Profile = profile; _scope = c.Scope; _points = Order(valid, c.Position);
        Index = 0; RoundsCompleted = 0; _moving = _chasing = _approachingTarget = false; _target = 0; _combatOn = false;
        _actionAt = now - 2000; _waitUntil = now; _targetSince = now;
        Deaths.Clear(); _observed.Clear(); Running = true; State = "准备农怪";
        return true;
    }

    private bool Reject(string reason) { State = reason; return false; }

    public void Stop(string reason = "已停止")
    {
        if (Running)
        {
            Running = false;
            try { if (_moving) host.StopMovement(); }
            finally { if (_combatOn) host.SetCombat(false); }
        }
        _moving = _combatOn = false; _target = 0; _observed.Clear(); State = reason;
    }

    public void Tick(long now)
    {
        if (!Running || Profile is not { } profile) return;
        var c = host.Context;
        if (!c.Ready || c.Scope != _scope) { Stop("地图、服务器或分线已变化，农怪已停止"); return; }
        if (c.Dead) { Stop("角色已死亡，农怪已停止"); return; }
        if (!host.NavigationReady || !host.MovementAllowed) { Stop("导航不可用或移动已暂停，农怪已停止"); return; }
        var mobs = host.Mobs;
        if (profile.StopOnName != 0 && mobs.Any(m => m.NameId == profile.StopOnName && m.Hp > 0))
        { Stop("发现巨大鳐，已停止农怪；请通知狩猎玩家"); return; }
        CountDeaths(mobs, profile.Names);
        if (c.Busy) { Stop("角色正在切图、过场或执行其他操作，农怪已停止"); return; }
        if (profile.Ground && c.Diving) { Stop("已离开洞穴陆地，农怪已停止"); return; }
        if (c.Combat)
        {
            if (_moving && !_chasing) { host.StopMovement(); _moving = false; }
            var enemy = mobs.Where(m => profile.Names.Contains(m.NameId) && m.Hp > 0 && Finite(m.Position) &&
                Vector3.Distance(m.Position,c.Position) <= 40).OrderBy(m => Vector3.DistanceSquared(m.Position,c.Position)).FirstOrDefault();
            var justEnabled=!_combatOn;
            if (!_combatOn)
            {
                if (enemy.Id == 0) { Stop("遭遇非目标怪物，请手动处理战斗后重新开始"); return; }
                _target=enemy.Id; _targetSince=now; host.Focus(enemy.Id); Combat(true);
            }
            if(enemy.Id!=0)
            {
                if(_target!=enemy.Id){_target=enemy.Id;_targetSince=now;}
                if(!justEnabled)host.Focus(enemy.Id);
            }
            if(enemy.Id!=0 && host.EngageDistance<25 && Vector3.Distance(enemy.Position,c.Position)>host.EngageDistance)
            {
                if(!_moving)
                {
                    if(host.NavigationBusy || !host.Move(enemy.Position,false)){Stop("无法靠近交战目标，请检查地面寻路");return;}
                    _moving=_chasing=_approachingTarget=true;_moveGoal=enemy.Position;_moveAt=_progressAt=now;_lastProgress=c.Position;
                }
                else
                {
                    if(Vector3.Distance(c.Position,_lastProgress)>1){_lastProgress=c.Position;_progressAt=now;}
                    if(now-_progressAt>20000 || now-_moveAt>60000 || (now-_moveAt>1500 && !host.NavigationBusy))
                    {Stop("靠近交战目标的路线已中断，农怪已停止");return;}
                }
                State="靠近交战目标";return;
            }
            if(_chasing){host.StopMovement();_moving=_chasing=false;}
            if (now - _targetSince > 180000) { Stop("战斗持续过久，请检查自动循环和角色状态"); return; }
            State = "战斗中，等待脱战"; return;
        }
        if(_chasing){host.StopMovement();_moving=_chasing=false;}
        if (now < _waitUntil) { State = "等待下一轮刷新"; return; }
        var point = _points[Index];
        var distance = Vector3.Distance(c.Position, point);
        if (_moving)
        {
            if (Vector3.Distance(c.Position,_moveGoal) <= Math.Min(3,host.EngageDistance)) { host.StopMovement(); _moving = false; _waitUntil = now + 500; return; }
            if (Vector3.Distance(c.Position, _lastProgress) >= 1) { _lastProgress = c.Position; _progressAt = now; }
            if (now - _moveAt > 120000 || now - _progressAt > 20000)
            { Stop("移动超时或卡住，请检查路线后重新开始"); return; }
            if (now - _moveAt > 1500 && !host.NavigationBusy)
            { Stop("寻路已被停止或未找到路线；不会自动重启"); return; }
            State = $"前往小怪点位 {Index + 1}/{_points.Count}"; return;
        }
        if (distance > 4 && !_approachingTarget)
        {
            Combat(false);
            if (host.NavigationBusy) { Stop("检测到其他导航任务，农怪已停止"); return; }
            if (!profile.Ground && !c.Mounted)
            { Action(now, host.Mount); State = "上坐骑"; return; }
            if (!profile.Ground && !c.Flying)
            { Action(now, host.TakeOff); State = "起飞"; return; }
            if (!host.Move(point, !profile.Ground)) { Stop("无法提交路线，请检查 vnavmesh"); return; }
            _moving = true; _moveGoal=point; _moveAt = _progressAt = now; _lastProgress = c.Position; return;
        }
        var target = mobs.Where(m => profile.Names.Contains(m.NameId) && m.Hp > 0 && Finite(m.Position) &&
            Vector3.Distance(m.Position, point) <= 25 && Vector3.Distance(m.Position, c.Position) <= 25)
            .OrderBy(m => _approachingTarget && m.Id==_target ? -1 : Vector3.DistanceSquared(m.Position, point)).FirstOrDefault();
        if (target.Id != 0)
        {
            if (_target != target.Id) { _target = target.Id; _targetSince = now; }
            if (now - _targetSince > 120000) { Stop("小怪长时间未击杀，请检查自动循环配置"); return; }
            if (Index == 0 && now - _targetSince < Math.Clamp(DelaySeconds, 0, 120) * 1000L)
            { State = "首只小怪延迟等待"; return; }
            if (c.Mounted) { Action(now, host.Dismount); State = "下坐骑"; return; }
            if(Vector3.Distance(c.Position,target.Position)>host.EngageDistance)
            {
                Combat(false);
                if(host.NavigationBusy){Stop("检测到其他导航任务，农怪已停止");return;}
                if(!host.Move(target.Position,false)){Stop("无法靠近目标小怪，请检查地面寻路");return;}
                _moving=_approachingTarget=true;_moveGoal=target.Position;_moveAt=_progressAt=now;_lastProgress=c.Position;return;
            }
            host.Focus(target.Id); Combat(true); State = "等待所选循环击杀小怪"; return;
        }
        Combat(false); _target = 0; _targetSince = now;_approachingTarget=false;
        Index++;
        if (Index >= _points.Count) { Index = 0; RoundsCompleted++; _waitUntil = now + 10000; }
        else _waitUntil = now + 500;
        State = "前往下一点";
    }

    private void CountDeaths(IReadOnlyList<FarmMob> mobs, uint[] names)
    {
        var present = new HashSet<ulong>();
        foreach (var mob in mobs.Where(m => names.Contains(m.NameId) && m.Id != 0 && m.MaxHp > 0))
        {
            present.Add(mob.Id);
            if (_observed.TryGetValue(mob.Id, out var previous) && previous.NameId == mob.NameId &&
                previous.Hp > 0 && mob.Hp == 0)
                Deaths[mob.NameId] = Deaths.GetValueOrDefault(mob.NameId) + 1;
            _observed[mob.Id] = mob;
        }
        foreach (var missing in _observed.Keys.Where(id => !present.Contains(id)).ToList()) _observed.Remove(missing);
    }

    private void Combat(bool on) { if (on != _combatOn) { host.SetCombat(on); _combatOn = on; } }
    private void Action(long now, Action action) { if (now - _actionAt >= 1500) { _actionAt = now; action(); } }
    public static bool Finite(Vector3 p) => float.IsFinite(p.X) && float.IsFinite(p.Y) && float.IsFinite(p.Z);
    public static List<Vector3> Order(IEnumerable<Vector3> points, Vector3 from)
    {
        var left = points.ToList(); List<Vector3> result = [];
        while (left.Count > 0) { var next = left.OrderBy(p => Vector3.DistanceSquared(from, p)).First(); result.Add(next); left.Remove(next); from = next; }
        return result;
    }
}
