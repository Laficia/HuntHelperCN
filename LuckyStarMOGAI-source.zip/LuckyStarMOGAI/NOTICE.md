LuckyStarMOGAI is derived from NiGuangOwO/LuckyStar, commit 51c2a355a44200eb59c374c8211001c80f4b9d30.
Original project: https://github.com/NiGuangOwO/LuckyStar
Original author: NiGuangOwO. Original license: AGPL-3.0-or-later.
Modified by Laficia on 2026-11-13: independent identity/version; CN farm profiles; Ruby Sea three-cave patrol, normal loading transitions, per-session observation counts, and lifecycle/stop handling.
ECommons 3.2.0.15: https://github.com/NightmareXIV/ECommons (MIT); see THIRD-PARTY-LICENSES/ECommons-MIT.txt.
Source, tests and build instructions accompany this release. No warranty; see LICENSE.md.
